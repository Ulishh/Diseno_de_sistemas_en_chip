import serial
from board import SCL, SDA
import busio
from PIL import Image, ImageDraw, ImageFont
import adafruit_ssd1306
import time
i2c = busio.I2C(SCL, SDA)
disp = adafruit_ssd1306.SSD1306_I2C(128, 64, i2c)
#crea pantalla en negro
disp.fill(0)
disp.show()
width = disp.width
height = disp.height
#Crea nueva imagen
image = Image.new('1', (width, height))
draw = ImageDraw.Draw(image)
font = ImageFont.load_default()
draw.text((10, 0), '******************', font=font, fill=255)
draw.text((10, 10), 'Ulises Hernandez', font=font, fill=255)
draw.text((10, 20), 'Alan Flores', font=font, fill=255)
draw.text((10, 30), 'Givka Morales', font=font, fill=255)
draw.text((10, 40), '******************', font=font, fill=255)
# Muestra Texto
disp.image(image)
disp.show()
time.sleep(3)
#Crea pantalla en negro
disp.fill(0)
disp.show()
# Crea nueva imagen
image1 = Image.new('1', (width, height))
draw1 = ImageDraw.Draw(image1)
font = ImageFont.load_default()
#Lee el puerto Serial
s = serial.Serial('/dev/ttyUSB0',9600)
x=0
for i in range(7):
	lectura = s.readline()
	draw1.text((10, x), lectura, font=font, fill=255)
	x=x+7
s.close()
# Muestra Texto
disp.image(image1)
disp.show()
